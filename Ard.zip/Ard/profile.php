<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="profile.css">
    <script src="profile.js"></script>

    <title>Profile</title>
    
</head>
<body>
    <div id="cont">
        <h1>Profile</h1>
        <div id="profile">
            <div id="profile-image">
                <img src="profile-image.jpg" alt="Profile Image">
            </div>
            <div id="profile-info">
                <p><strong>Email:</strong> artariq08@gmail.com</p>
                <p><strong>Password:</strong> <span id="password">AbdulRehman08</span></p>
            </div>
            <div id="reset-password">
                <button onclick="resetPassword()">Reset Password</button>
            </div>
        </div>
    </div>
</body>
</html>

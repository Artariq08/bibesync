function register() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Perform registration logic here
    console.log(`Registered with username: ${username}, password: ${password}`);
  }